
# amanullahshanavas.github.io

Simple GitHub Pages portfolio for **Amanullah S** — generated automatically.

## How to use
1. Create a GitHub repository named `amanullahshanavas.github.io`.
2. Upload the files from this folder to the repository root:
   - index.html
   - styles.css
   - Amanullah_Resume.pdf
3. In GitHub, go to **Settings → Pages**, set source to `main` branch and root (`/`), and save.
4. Your site will be available at: `https://amanullahshanavas.github.io`

## Files included
- index.html — main webpage
- styles.css — styles for the page
- Amanullah_Resume.pdf — resume (copied from your uploaded PDF)
